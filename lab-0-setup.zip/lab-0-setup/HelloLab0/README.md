\# Lab 0 – Development Environment Setup



Name: Muhammad Abdul Quddous 

Lab 0 setup successful

OS: Microsoft Windows NT 10.0.26100.0

.NET: 10.0.1

